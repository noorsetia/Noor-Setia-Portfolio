import React, { useState } from 'react';
import Reveal from './Reveal';
import { personalInfo } from '../data/personalInfo';

export default function Contact() {
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [errors, setErrors] = useState({});
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [copyFeedback, setCopyFeedback] = useState('');

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) setErrors((prev) => ({ ...prev, [name]: '' }));
  };

  const copyToClipboard = (text, label) => {
    navigator.clipboard.writeText(text);
    setCopyFeedback(`${label} copied to clipboard!`);
    setTimeout(() => setCopyFeedback(''), 3000);
  };

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Please provide your name';
    if (!formData.email.trim()) newErrors.email = 'Please provide an email address';
    else if (!/\S+@\S+\.\S+/.test(formData.email)) newErrors.email = 'Please enter a valid email';
    if (!formData.message.trim()) newErrors.message = 'Please write a message';
    return newErrors;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const validationErrors = validate();
    
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }

    setIsSubmitting(true);

    try {
      const response = await fetch("https://api.web3forms.com/submit", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
        },
        body: JSON.stringify({
          access_key: "3bee2b90-fa51-415d-90b1-a076db166e2b", 
          name: formData.name,
          email: formData.email,
          message: formData.message,
        }),
      });

      const result = await response.json();

      if (result.success) {
        setIsSubmitted(true);
        setFormData({ name: '', email: '', message: '' });
        setTimeout(() => setIsSubmitted(false), 6000);
      } else {
        setErrors({ submit: "Submission error. Please email directly." });
      }
    } catch {
      setErrors({ submit: "Network connectivity issue. Please reach out via email." });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section id="contact" className="py-28 px-6 bg-white dark:bg-[#07090E] transition-colors duration-300 overflow-hidden border-t border-slate-200 dark:border-white/[0.04]">
      <div className="max-w-6xl mx-auto">
        
        {/* Section Header */}
        <Reveal direction="up" delay={0}>
          <div className="mb-16">
            <span className="text-xs font-mono font-semibold uppercase tracking-wider text-blue-600 dark:text-blue-400">
              05. Get In Touch
            </span>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-slate-900 dark:text-white tracking-tight mt-2">
              Let's Build Something Solid
            </h2>
            <div className="w-16 h-1 bg-blue-600 mt-4 rounded-full"></div>
            <p className="text-slate-600 dark:text-slate-400 text-base sm:text-lg max-w-xl mt-4">
              Open to Frontend and Full Stack opportunities. Let's discuss engineering roles, project collaborations, or developer ideas.
            </p>
          </div>
        </Reveal>

        {/* Copy Feedback Toast */}
        {copyFeedback && (
          <div className="fixed bottom-6 right-6 z-50 bg-slate-900 dark:bg-blue-600 text-white text-xs font-mono font-medium px-4 py-2.5 rounded-xl shadow-2xl flex items-center gap-2 animate-fade-in">
            <svg className="w-4 h-4 text-emerald-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
            </svg>
            {copyFeedback}
          </div>
        )}

        <div className="grid md:grid-cols-12 gap-12 items-start">
          
          {/* LEFT COLUMN - INTERACTIVE FORM */}
          <div className="md:col-span-7">
            <Reveal direction="left" delay={150}>
              <div className="bg-slate-50 dark:bg-[#0B0F19] border border-slate-200 dark:border-white/[0.08] p-6 sm:p-8 rounded-2xl shadow-sm">
                {isSubmitted ? (
                  <div className="py-12 text-center flex flex-col justify-center items-center">
                    <div className="w-16 h-16 bg-blue-50 dark:bg-blue-500/10 rounded-2xl flex items-center justify-center mb-5 text-blue-600 dark:text-blue-400 border border-blue-200 dark:border-blue-500/20">
                      <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                    </div>
                    <h4 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">Message Delivered</h4>
                    <p className="text-slate-600 dark:text-slate-300 text-sm max-w-sm">
                      Thank you for contacting me. I will review your note and respond promptly.
                    </p>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-5">
                    <div>
                      <label htmlFor="name" className="block text-xs font-mono font-semibold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-2">
                        Your Name
                      </label>
                      <input
                        type="text"
                        id="name"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        disabled={isSubmitting}
                        className={`w-full bg-white dark:bg-[#0E1424] border ${errors.name ? 'border-red-500' : 'border-slate-300 dark:border-white/[0.08]'} rounded-xl px-4 py-3 text-sm text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-colors disabled:opacity-50`}
                        placeholder="Alex Morgan"
                      />
                      {errors.name && <p className="mt-1 text-xs text-red-500 dark:text-red-400">{errors.name}</p>}
                    </div>
                    
                    <div>
                      <label htmlFor="email" className="block text-xs font-mono font-semibold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-2">
                        Email Address
                      </label>
                      <input
                        type="email"
                        id="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        disabled={isSubmitting}
                        className={`w-full bg-white dark:bg-[#0E1424] border ${errors.email ? 'border-red-500' : 'border-slate-300 dark:border-white/[0.08]'} rounded-xl px-4 py-3 text-sm text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-colors disabled:opacity-50`}
                        placeholder="alex@company.com"
                      />
                      {errors.email && <p className="mt-1 text-xs text-red-500 dark:text-red-400">{errors.email}</p>}
                    </div>
                    
                    <div>
                      <label htmlFor="message" className="block text-xs font-mono font-semibold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-2">
                        Project or Message Details
                      </label>
                      <textarea
                        id="message"
                        name="message"
                        rows="5"
                        value={formData.message}
                        onChange={handleChange}
                        disabled={isSubmitting}
                        className={`w-full bg-white dark:bg-[#0E1424] border ${errors.message ? 'border-red-500' : 'border-slate-300 dark:border-white/[0.08]'} rounded-xl px-4 py-3 text-sm text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-colors resize-none disabled:opacity-50`}
                        placeholder="Tell me about your team, tech stack, or engineering opportunity..."
                      ></textarea>
                      {errors.message && <p className="mt-1 text-xs text-red-500 dark:text-red-400">{errors.message}</p>}
                    </div>

                    {errors.submit && (
                      <p className="text-xs text-red-500 font-mono text-center p-2 bg-red-50 dark:bg-red-500/10 rounded-lg border border-red-200 dark:border-red-500/20">
                        {errors.submit}
                      </p>
                    )}
                    
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full bg-blue-600 hover:bg-blue-500 text-white font-semibold py-3.5 rounded-xl transition-all shadow-md shadow-blue-500/25 flex items-center justify-center gap-2 disabled:opacity-70 disabled:cursor-not-allowed cursor-pointer focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      {isSubmitting ? (
                        <>
                          <svg className="animate-spin h-4 w-4 text-white" viewBox="0 0 24 24" fill="none">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                          </svg>
                          <span>Transmitting Message...</span>
                        </>
                      ) : (
                        <>
                          <span>Send Message</span>
                          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3" />
                          </svg>
                        </>
                      )}
                    </button>
                  </form>
                )}
              </div>
            </Reveal>
          </div>

          {/* RIGHT COLUMN - DIRECT DETAILS & QUICK ACTIONS */}
          <div className="md:col-span-5 space-y-6">
            <Reveal direction="right" delay={250}>
              <div className="bg-slate-50 dark:bg-[#0B0F19] border border-slate-200 dark:border-white/[0.08] p-6 rounded-2xl shadow-sm">
                <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-3">Direct Channels</h3>
                <p className="text-slate-600 dark:text-slate-400 text-sm leading-relaxed mb-6">
                  Feel free to reach out directly via email or phone. I usually respond within 24 hours.
                </p>

                <div className="space-y-3">
                  {/* Email Card */}
                  <div className="flex items-center justify-between p-3.5 rounded-xl bg-white dark:bg-[#0E1424] border border-slate-200 dark:border-white/[0.06] shadow-sm">
                    <div className="overflow-hidden">
                      <p className="text-[10px] font-mono uppercase text-slate-400 dark:text-slate-500">Email</p>
                      <a href={`mailto:${personalInfo.email}`} className="text-xs sm:text-sm font-medium text-slate-800 dark:text-white hover:text-blue-600 dark:hover:text-blue-400 transition-colors truncate block">
                        {personalInfo.email}
                      </a>
                    </div>
                    <button
                      onClick={() => copyToClipboard(personalInfo.email, 'Email')}
                      className="px-2.5 py-1 text-xs font-mono bg-slate-100 hover:bg-slate-200 dark:bg-white/[0.05] dark:hover:bg-white/[0.1] text-slate-700 dark:text-slate-300 rounded border border-slate-300 dark:border-white/[0.08] transition-colors cursor-pointer"
                      title="Copy email to clipboard"
                    >
                      Copy
                    </button>
                  </div>

                  {/* Phone Card */}
                  <div className="flex items-center justify-between p-3.5 rounded-xl bg-white dark:bg-[#0E1424] border border-slate-200 dark:border-white/[0.06] shadow-sm">
                    <div>
                      <p className="text-[10px] font-mono uppercase text-slate-400 dark:text-slate-500">Phone</p>
                      <a href={`tel:${personalInfo.phone.replace(/[\s-]/g, '')}`} className="text-xs sm:text-sm font-medium text-slate-800 dark:text-white hover:text-blue-600 dark:hover:text-blue-400 transition-colors">
                        {personalInfo.phone}
                      </a>
                    </div>
                    <button
                      onClick={() => copyToClipboard(personalInfo.phone, 'Phone')}
                      className="px-2.5 py-1 text-xs font-mono bg-slate-100 hover:bg-slate-200 dark:bg-white/[0.05] dark:hover:bg-white/[0.1] text-slate-700 dark:text-slate-300 rounded border border-slate-300 dark:border-white/[0.08] transition-colors cursor-pointer"
                      title="Copy phone number to clipboard"
                    >
                      Copy
                    </button>
                  </div>

                  {/* Location Card */}
                  <div className="p-3.5 rounded-xl bg-white dark:bg-[#0E1424] border border-slate-200 dark:border-white/[0.06] shadow-sm">
                    <p className="text-[10px] font-mono uppercase text-slate-400 dark:text-slate-500">Location</p>
                    <p className="text-xs sm:text-sm font-medium text-slate-800 dark:text-white">
                      {personalInfo.location}
                    </p>
                  </div>
                </div>
              </div>
            </Reveal>

            {/* Social Network Links */}
            <Reveal direction="right" delay={350}>
              <div className="bg-slate-50 dark:bg-[#0B0F19] border border-slate-200 dark:border-white/[0.08] p-6 rounded-2xl shadow-sm">
                <h4 className="text-xs font-mono font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-4">
                  Professional Profiles
                </h4>
                <div className="flex flex-col gap-2.5">
                  <a
                    href={personalInfo.socialLinks.github}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center justify-between p-3 rounded-xl bg-white dark:bg-[#0E1424] border border-slate-200 dark:border-white/[0.06] text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:border-blue-500/40 transition-all text-xs sm:text-sm font-medium shadow-sm"
                  >
                    <span>GitHub: /noorsetia</span>
                    <span className="text-blue-600 dark:text-blue-400 font-mono text-xs">Explore Code ↗</span>
                  </a>

                  <a
                    href={personalInfo.socialLinks.linkedin}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center justify-between p-3 rounded-xl bg-white dark:bg-[#0E1424] border border-slate-200 dark:border-white/[0.06] text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:border-blue-500/40 transition-all text-xs sm:text-sm font-medium shadow-sm"
                  >
                    <span>LinkedIn: /in/noorsetia</span>
                    <span className="text-blue-600 dark:text-blue-400 font-mono text-xs">Connect ↗</span>
                  </a>
                </div>
              </div>
            </Reveal>
          </div>

        </div>

      </div>
    </section>
  );
}