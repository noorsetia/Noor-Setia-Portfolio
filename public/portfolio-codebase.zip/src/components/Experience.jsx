import React, { useState, useMemo } from 'react';
import Reveal from './Reveal';
import { experiences } from '../data/experienceData';

export default function Experience() {
  const [activeTab, setActiveTab] = useState('all');

  const filteredExperiences = useMemo(() => {
    if (activeTab === 'all') return experiences;
    if (activeTab === 'work') return experiences.filter(e => e.type.toLowerCase().includes('work'));
    if (activeTab === 'education') return experiences.filter(e => e.type.toLowerCase().includes('education'));
    return experiences;
  }, [activeTab]);

  return (
    <section id="experience" className="py-28 px-6 bg-slate-50 dark:bg-[#07090E] transition-colors duration-300 overflow-hidden border-t border-slate-200 dark:border-white/[0.04]">
      <div className="max-w-4xl mx-auto">
        
        {/* Section Header */}
        <Reveal direction="up" delay={0}>
          <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-12 gap-6">
            <div>
              <span className="text-xs font-mono font-semibold uppercase tracking-wider text-blue-600 dark:text-blue-400">
                04. Career Journey
              </span>
              <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-slate-900 dark:text-white tracking-tight mt-2">
                Experience & Education
              </h2>
              <div className="w-16 h-1 bg-blue-600 mt-4 rounded-full"></div>
            </div>

            {/* Segmented Filter Control */}
            <div className="inline-flex p-1 bg-slate-200 dark:bg-[#0E1321] rounded-xl border border-slate-300 dark:border-white/[0.08] self-start sm:self-auto shadow-sm">
              <button
                onClick={() => setActiveTab('all')}
                className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                  activeTab === 'all'
                    ? 'bg-white dark:bg-blue-600 text-slate-900 dark:text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                }`}
              >
                All Milestones
              </button>
              <button
                onClick={() => setActiveTab('work')}
                className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                  activeTab === 'work'
                    ? 'bg-white dark:bg-blue-600 text-slate-900 dark:text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                }`}
              >
                Work & Leadership
              </button>
              <button
                onClick={() => setActiveTab('education')}
                className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                  activeTab === 'education'
                    ? 'bg-white dark:bg-blue-600 text-slate-900 dark:text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                }`}
              >
                Education
              </button>
            </div>
          </div>
        </Reveal>

        {/* Timeline Stream */}
        <div className="relative border-l border-slate-300 dark:border-white/[0.12] ml-4 sm:ml-6 space-y-10">
          {filteredExperiences.map((item, index) => (
            <Reveal key={`${item.title}-${index}`} direction="up" delay={150 + (index * 100)} className="relative pl-8 sm:pl-10">
              
              {/* Timeline Indicator Dot */}
              <div className="absolute w-3.5 h-3.5 bg-blue-600 dark:bg-blue-500 rounded-full -left-[7px] top-2 ring-4 ring-slate-50 dark:ring-[#07090E]"></div>
              
              {/* Milestone Card */}
              <div className="bg-white dark:bg-[#0B0F19] border border-slate-200 dark:border-white/[0.08] hover:border-blue-500/40 p-6 sm:p-8 rounded-2xl transition-all duration-300 shadow-sm group">
                
                <div className="flex flex-col sm:flex-row sm:justify-between sm:items-start mb-4 gap-2">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-[11px] font-mono font-semibold uppercase tracking-wider text-blue-600 dark:text-blue-400">
                        {item.type}
                      </span>
                      <span className="text-slate-400 dark:text-slate-600">·</span>
                      <span className="text-xs font-mono text-slate-500 dark:text-slate-400">
                        {item.organization}
                      </span>
                    </div>

                    <h3 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                      {item.title}
                    </h3>
                  </div>

                  {/* Date Badge */}
                  <div className="text-xs font-mono font-medium text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-white/[0.05] border border-slate-200 dark:border-white/[0.08] px-3 py-1 rounded-full w-fit shrink-0 sm:mt-1">
                    {item.date}
                  </div>
                </div>

                {/* Details List */}
                <ul className="space-y-2.5 mt-5">
                  {item.details.map((desc, idx) => (
                    <li key={idx} className="flex items-start text-slate-600 dark:text-slate-300 text-sm leading-relaxed">
                      <span className="text-blue-600 dark:text-blue-500 mr-2.5 mt-1 font-bold">›</span>
                      <span>{desc}</span>
                    </li>
                  ))}
                </ul>

              </div>
            </Reveal>
          ))}
        </div>

      </div>
    </section>
  );
}