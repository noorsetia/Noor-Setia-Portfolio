import React from 'react';
import { personalInfo } from '../data/personalInfo';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-slate-100 dark:bg-[#05070B] border-t border-slate-200 dark:border-white/[0.08] py-12 px-6 transition-colors duration-300">
      <div className="max-w-6xl mx-auto flex flex-col md:flex-row justify-between items-center gap-6">
        
        {/* Brand & Tagline */}
        <div className="flex flex-col sm:flex-row items-center gap-4 text-center sm:text-left">
          <a 
            href="#" 
            className="text-lg font-bold font-mono tracking-tight text-slate-900 dark:text-white hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
          >
            &lt;NoorSetia /&gt;
          </a>
          <span className="hidden sm:inline text-slate-300 dark:text-slate-700">·</span>
          <p className="text-xs text-slate-600 dark:text-slate-400 font-mono">
            Full Stack MERN Developer
          </p>
        </div>

        {/* Action Links */}
        <div className="flex items-center gap-6 text-xs font-mono text-slate-600 dark:text-slate-400">
          <a 
            href={personalInfo.socialLinks.github} 
            target="_blank" 
            rel="noreferrer"
            className="hover:text-slate-900 dark:hover:text-white transition-colors"
          >
            GitHub
          </a>
          <a 
            href={personalInfo.socialLinks.linkedin} 
            target="_blank" 
            rel="noreferrer"
            className="hover:text-slate-900 dark:hover:text-white transition-colors"
          >
            LinkedIn
          </a>
          <a 
            href={`mailto:${personalInfo.email}`}
            className="hover:text-slate-900 dark:hover:text-white transition-colors"
          >
            Email
          </a>
          {personalInfo.resumeUrl && (
            <a 
              href={personalInfo.resumeUrl} 
              target="_blank" 
              rel="noreferrer"
              className="text-blue-600 dark:text-blue-400 hover:underline transition-colors font-semibold"
            >
              Resume ↗
            </a>
          )}
        </div>

        {/* Copyright */}
        <p className="text-xs text-slate-500 font-mono">
          &copy; {currentYear} {personalInfo.name}. All rights reserved.
        </p>

      </div>
    </footer>
  );
}
