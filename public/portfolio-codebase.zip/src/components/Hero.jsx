import React from 'react';
import Reveal from './Reveal';
import myProfileImg from '../assets/profile.jpg';
import { personalInfo } from '../data/personalInfo';

export default function Hero() {
  return (
    <section className="relative min-h-[92vh] flex flex-col justify-center pt-28 pb-16 px-6 overflow-hidden bg-slate-50 dark:bg-[#07090E] transition-colors duration-300">
      {/* Subtle Ambient Radial Lighting */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-blue-500/10 dark:bg-blue-600/10 blur-[140px] rounded-full pointer-events-none -z-10"></div>
      <div className="absolute top-1/3 right-10 w-[300px] h-[300px] bg-indigo-500/5 dark:bg-indigo-600/10 blur-[120px] rounded-full pointer-events-none -z-10"></div>

      <div className="max-w-6xl mx-auto w-full">
        {/* Split Hero: Content & Profile Card */}
        <div className="grid lg:grid-cols-12 gap-12 lg:gap-8 items-center mb-16">
          
          {/* Left Column: Headline, Bio & CTAs */}
          <div className="lg:col-span-7 flex flex-col items-start">
            <Reveal direction="up" delay={50}>
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-50 dark:bg-blue-500/10 border border-blue-200 dark:border-blue-500/20 text-blue-700 dark:text-blue-400 text-xs font-mono mb-6">
                <span>Available for Opportunities</span>
                <span className="text-slate-400 dark:text-slate-500">·</span>
                <span>Full Stack & Frontend Developer</span>
              </div>
            </Reveal>

            <Reveal direction="up" delay={150}>
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-slate-900 dark:text-white tracking-tight leading-[1.08] mb-4 text-balance">
                Building scalable web apps with clean architecture.
              </h1>
            </Reveal>

            <Reveal direction="up" delay={250}>
              <p className="text-lg sm:text-xl font-medium text-blue-600 dark:text-blue-400 mb-4 font-mono">
                Noor Setia <span className="text-slate-400 dark:text-slate-500">/</span> {personalInfo.role}
              </p>
              <p className="text-base sm:text-lg text-slate-600 dark:text-slate-300 mb-8 leading-relaxed max-w-xl">
                {personalInfo.bio} Specialized in modern React, modular Express REST APIs, performant state management, and robust MongoDB schemas.
              </p>
            </Reveal>

            <Reveal direction="up" delay={350}>
              <div className="flex flex-wrap items-center gap-3 mb-8">
                <a
                  href="#projects"
                  className="inline-flex items-center gap-2 px-6 py-3.5 bg-blue-600 hover:bg-blue-500 text-white font-semibold text-sm rounded-xl transition-all shadow-lg shadow-blue-500/25 hover:-translate-y-0.5"
                >
                  Explore Featured Work
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3" />
                  </svg>
                </a>

                <a
                  href="#contact"
                  className="inline-flex items-center gap-2 px-5 py-3.5 bg-white dark:bg-[#0F1626] hover:bg-slate-100 dark:hover:bg-[#152037] border border-slate-300 dark:border-white/10 hover:border-slate-400 dark:hover:border-white/20 text-slate-800 dark:text-slate-200 font-semibold text-sm rounded-xl transition-all hover:-translate-y-0.5 shadow-sm"
                >
                  Contact Me
                </a>

                {personalInfo.resumeUrl && (
                  <a
                    href={personalInfo.resumeUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-2 px-4 py-3.5 text-slate-600 dark:text-slate-400 hover:text-blue-600 dark:hover:text-white font-medium text-sm transition-colors"
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                    </svg>
                    Resume
                  </a>
                )}
              </div>

              {/* Social Connect Inline */}
              <div className="flex items-center gap-4 text-xs font-mono text-slate-500 dark:text-slate-400">
                <span className="text-slate-400 dark:text-slate-500 uppercase tracking-wider">Connect:</span>
                <a 
                  href={personalInfo.socialLinks.github} 
                  target="_blank" 
                  rel="noreferrer"
                  className="hover:text-blue-600 dark:hover:text-blue-400 transition-colors flex items-center gap-1.5"
                >
                  GitHub
                </a>
                <span>·</span>
                <a 
                  href={personalInfo.socialLinks.linkedin} 
                  target="_blank" 
                  rel="noreferrer"
                  className="hover:text-blue-600 dark:hover:text-blue-400 transition-colors flex items-center gap-1.5"
                >
                  LinkedIn
                </a>
                <span>·</span>
                <a 
                  href={personalInfo.socialLinks.email}
                  className="hover:text-blue-600 dark:hover:text-blue-400 transition-colors flex items-center gap-1.5"
                >
                  Email
                </a>
              </div>
            </Reveal>
          </div>

          {/* Right Column: High-End Developer Profile Showcase Card */}
          <div className="lg:col-span-5 flex justify-center lg:justify-end">
            <Reveal direction="right" delay={300} className="w-full max-w-md">
              <div className="relative rounded-2xl bg-white dark:bg-[#0C111E] border border-slate-200 dark:border-white/[0.08] p-6 shadow-xl dark:shadow-2xl dark:shadow-black/60 overflow-hidden group">
                
                {/* Profile Image & Status Badge */}
                <div className="relative aspect-square w-full rounded-xl overflow-hidden mb-6 bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-white/[0.06]">
                  <img
                    src={myProfileImg}
                    alt={personalInfo.name}
                    className="w-full h-full object-cover transition-all duration-700 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 dark:from-[#0C111E] via-transparent to-transparent opacity-80"></div>
                  
                  <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between text-xs font-mono bg-white/90 dark:bg-black/60 backdrop-blur-md px-3.5 py-2 rounded-lg border border-slate-200 dark:border-white/10 text-slate-900 dark:text-slate-200 shadow-sm">
                    <span className="font-semibold">Full Stack Engineer</span>
                    <span className="text-blue-600 dark:text-blue-400">React · Node · Mongo</span>
                  </div>
                </div>

                {/* Developer Card Details */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-500 dark:text-slate-400 font-mono text-xs">Based in</span>
                    <span className="text-slate-800 dark:text-slate-200 font-medium">{personalInfo.location}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-500 dark:text-slate-400 font-mono text-xs">Current Focus</span>
                    <span className="text-blue-600 dark:text-blue-400 font-medium">Learning AI / ML & System Design</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-500 dark:text-slate-400 font-mono text-xs">Degree</span>
                    <span className="text-slate-800 dark:text-slate-200 font-medium">BCA (Software Dev, 2024–2027)</span>
                  </div>
                </div>
              </div>
            </Reveal>
          </div>

        </div>

        {/* Full-Width Key Metrics Strip */}
        <Reveal direction="up" delay={450}>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 p-5 rounded-2xl bg-white dark:bg-[#0A0F1B] border border-slate-200 dark:border-white/[0.08] shadow-sm">
            <div className="p-3">
              <p className="text-2xl sm:text-3xl font-extrabold text-blue-600 dark:text-blue-400 font-mono tracking-tight">AI / ML</p>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 uppercase tracking-wider font-mono">Current Learning</p>
            </div>
            <div className="p-3">
              <p className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white font-mono tracking-tight">MERN</p>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 uppercase tracking-wider font-mono">Full Stack Core</p>
            </div>
            <div className="p-3">
              <p className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white font-mono tracking-tight">4+ Apps</p>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 uppercase tracking-wider font-mono">Shipped to Web</p>
            </div>
            <div className="p-3">
              <p className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white font-mono tracking-tight">2027</p>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 uppercase tracking-wider font-mono">BCA Candidate</p>
            </div>
          </div>
        </Reveal>

      </div>
    </section>
  );
}