import React, { useState } from 'react';

/**
 * ProjectVisual Component
 * 
 * Renders authentic screenshots when available, or provides a clean, restrained,
 * domain-accurate UI wireframe placeholder that clearly signals where the real
 * screenshot belongs, without stock photography or fabricated visuals.
 */
export default function ProjectVisual({ project, className = "", isModal = false }) {
  const [imageError, setImageError] = useState(false);

  // If real screenshot is supplied and hasn't errored
  if (project.screenshotUrl && !imageError) {
    return (
      <div className={`relative overflow-hidden w-full ${isModal ? 'h-52 sm:h-64' : 'h-52 sm:h-60'} bg-slate-900 ${className}`}>
        <img
          src={project.screenshotUrl}
          alt={`Interface screenshot of ${project.title}`}
          onError={() => setImageError(true)}
          className="w-full h-full object-cover object-top transition-transform duration-500 ease-out group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 dark:from-[#0B0F19] via-transparent to-transparent opacity-80 pointer-events-none"></div>
      </div>
    );
  }

  // Authentic, restrained developer wireframe placeholder:
  return (
    <div 
      className={`relative overflow-hidden w-full ${isModal ? 'h-52 sm:h-64' : 'h-52 sm:h-60'} bg-[#0B0F19] dark:bg-[#070A12] border-b border-slate-200 dark:border-white/[0.08] flex flex-col justify-between p-4 sm:p-5 select-none ${className}`}
      aria-label={`UI Schematic preview for ${project.title}`}
    >
      {/* Background Architectural Grid Pattern */}
      <div 
        className="absolute inset-0 opacity-[0.04] dark:opacity-[0.07] pointer-events-none"
        style={{
          backgroundImage: `radial-gradient(circle at 1px 1px, #3B82F6 1px, transparent 0)`,
          backgroundSize: '16px 16px'
        }}
        aria-hidden="true"
      />

      {/* Mockup Window Chrome Header */}
      <div className="relative z-10 flex items-center justify-between gap-2 pb-2 border-b border-slate-800/80">
        <div className="flex items-center gap-1.5">
          <span className="w-2.5 h-2.5 rounded-full bg-slate-700/80"></span>
          <span className="w-2.5 h-2.5 rounded-full bg-slate-700/80"></span>
          <span className="w-2.5 h-2.5 rounded-full bg-slate-700/80"></span>
        </div>

        <div className="flex items-center gap-1.5 px-2.5 py-0.5 rounded bg-slate-900/90 border border-slate-800 text-[10px] font-mono text-slate-400 max-w-[200px] truncate">
          <svg className="w-3 h-3 text-blue-400 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
          </svg>
          <span className="truncate">{project.category.toLowerCase().replace(/\s+/g, '-')}.local</span>
        </div>

        <span className="text-[10px] font-mono text-blue-400 bg-blue-500/10 px-2 py-0.5 rounded border border-blue-500/20 uppercase">
          {project.category}
        </span>
      </div>

      {/* Project-Specific Schematic Wireframe */}
      <div className="relative z-10 my-auto py-2">
        {project.id === 1 && (
          /* NESTORA E-Commerce Schematic */
          <div className="space-y-2 max-w-sm mx-auto">
            <div className="flex items-center justify-between text-xs text-slate-400 font-mono">
              <span className="text-white font-medium">Catalog & Cart View</span>
              <span className="text-emerald-400 text-[11px]">Razorpay Active</span>
            </div>
            <div className="grid grid-cols-3 gap-2">
              <div className="h-12 rounded bg-slate-800/60 border border-slate-700/50 p-1.5 flex flex-col justify-between">
                <div className="h-2 w-8 bg-slate-600 rounded"></div>
                <div className="h-2 w-12 bg-blue-500/40 rounded"></div>
              </div>
              <div className="h-12 rounded bg-slate-800/60 border border-slate-700/50 p-1.5 flex flex-col justify-between">
                <div className="h-2 w-8 bg-slate-600 rounded"></div>
                <div className="h-2 w-12 bg-blue-500/40 rounded"></div>
              </div>
              <div className="h-12 rounded bg-slate-800/60 border border-slate-700/50 p-1.5 flex flex-col justify-between">
                <div className="h-2 w-8 bg-slate-600 rounded"></div>
                <div className="h-2 w-12 bg-blue-500/40 rounded"></div>
              </div>
            </div>
          </div>
        )}

        {project.id === 2 && (
          /* CareSync Healthcare Schematic */
          <div className="space-y-2 max-w-sm mx-auto">
            <div className="flex items-center justify-between text-xs text-slate-400 font-mono">
              <span className="text-white font-medium">Clinical Scheduling & Patient Flow</span>
              <span className="text-cyan-400 text-[11px]">React Router</span>
            </div>
            <div className="space-y-1.5">
              <div className="h-4 rounded bg-slate-800/80 border border-slate-700/50 flex items-center px-2 justify-between">
                <span className="h-1.5 w-16 bg-slate-500 rounded"></span>
                <span className="h-1.5 w-8 bg-cyan-400/60 rounded"></span>
              </div>
              <div className="h-4 rounded bg-slate-800/80 border border-slate-700/50 flex items-center px-2 justify-between">
                <span className="h-1.5 w-20 bg-slate-500 rounded"></span>
                <span className="h-1.5 w-8 bg-cyan-400/60 rounded"></span>
              </div>
            </div>
          </div>
        )}

        {project.id === 3 && (
          /* World Countries Schematic */
          <div className="space-y-2 max-w-sm mx-auto">
            <div className="flex items-center justify-between text-xs text-slate-400 font-mono">
              <span className="text-white font-medium">Demographic Query & Chart.js</span>
              <span className="text-blue-400 text-[11px]">Dynamic O(1) Map</span>
            </div>
            <div className="flex items-end gap-1.5 h-10 pt-2 border-b border-slate-800">
              <div className="w-1/6 bg-blue-500/60 rounded-t h-[40%]"></div>
              <div className="w-1/6 bg-blue-500/80 rounded-t h-[80%]"></div>
              <div className="w-1/6 bg-blue-400 rounded-t h-[100%]"></div>
              <div className="w-1/6 bg-blue-500/70 rounded-t h-[60%]"></div>
              <div className="w-1/6 bg-blue-500/50 rounded-t h-[35%]"></div>
              <div className="w-1/6 bg-blue-500/90 rounded-t h-[75%]"></div>
            </div>
          </div>
        )}

        {project.id === 4 && (
          /* GYM MERN Schematic */
          <div className="space-y-2 max-w-sm mx-auto">
            <div className="flex items-center justify-between text-xs text-slate-400 font-mono">
              <span className="text-white font-medium">Workout Splits & BMI Metric</span>
              <span className="text-indigo-400 text-[11px]">Express + Mongo</span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div className="h-10 rounded bg-slate-800/60 border border-slate-700/50 p-1.5 flex items-center justify-between">
                <span className="text-[10px] font-mono text-slate-400">BMI Engine</span>
                <span className="text-xs font-mono text-emerald-400 font-bold">22.4</span>
              </div>
              <div className="h-10 rounded bg-slate-800/60 border border-slate-700/50 p-1.5 flex items-center justify-between">
                <span className="text-[10px] font-mono text-slate-400">Tiers</span>
                <span className="text-xs font-mono text-blue-400 font-bold">REST API</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Bottom Placeholder Notice */}
      <div className="relative z-10 flex items-center justify-between pt-2 border-t border-slate-800/60 text-[11px] font-mono text-slate-400">
        <span className="flex items-center gap-1.5">
          <span className="w-1.5 h-1.5 rounded-full bg-blue-400"></span>
          <span>{project.screenshotPlaceholder}</span>
        </span>
        <span className="text-[10px] text-slate-500 hidden sm:inline">
          Screenshot Pending
        </span>
      </div>
    </div>
  );
}
