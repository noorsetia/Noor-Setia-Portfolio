import React, { useState, useMemo } from 'react';
import Reveal from './Reveal';
import { projectsData } from '../data/projectsData';
import ProjectVisual from './ProjectVisual';

export default function Projects({ onOpenProjectModal }) {
  const [activeCategory, setActiveCategory] = useState('All');

  const categories = ['All', 'MERN Stack', 'Frontend & UI', 'Data & Tools'];

  const filteredProjects = useMemo(() => {
    if (activeCategory === 'All') return projectsData;
    return projectsData.filter(p => p.category === activeCategory);
  }, [activeCategory]);

  return (
    <section 
      id="projects" 
      className="py-24 sm:py-28 px-4 sm:px-6 bg-white dark:bg-[#07090E] transition-colors duration-300 overflow-hidden border-t border-slate-200 dark:border-white/[0.04]"
      aria-labelledby="projects-heading"
    >
      <div className="max-w-6xl mx-auto">
        
        {/* Section Header */}
        <Reveal direction="up" delay={0}>
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 sm:mb-12 gap-6">
            <div>
              <span className="text-xs font-mono font-semibold uppercase tracking-wider text-blue-600 dark:text-blue-400">
                03. Selected Works
              </span>
              <h2 id="projects-heading" className="text-3xl sm:text-4xl md:text-5xl font-bold text-slate-900 dark:text-white tracking-tight mt-2">
                Production-Ready Projects
              </h2>
              <div className="w-16 h-1 bg-blue-600 mt-4 rounded-full" aria-hidden="true"></div>
            </div>

            {/* Category Filter Tabs */}
            <div 
              className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none"
              role="tablist"
              aria-label="Filter projects by technical category"
            >
              {categories.map((cat) => {
                const isActive = activeCategory === cat;
                return (
                  <button
                    key={cat}
                    role="tab"
                    aria-selected={isActive}
                    onClick={() => setActiveCategory(cat)}
                    className={`px-3.5 sm:px-4 py-2 text-xs sm:text-sm font-medium rounded-xl whitespace-nowrap transition-all duration-200 cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 ${
                      isActive
                        ? 'bg-blue-600 text-white shadow-md shadow-blue-500/20'
                        : 'bg-slate-100 dark:bg-[#0E1321] text-slate-700 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-200 dark:hover:bg-[#151D33] border border-slate-200 dark:border-white/[0.06]'
                    }`}
                  >
                    {cat}
                  </button>
                );
              })}
            </div>
          </div>
        </Reveal>

        {/* Projects Grid */}
        <div className="grid md:grid-cols-2 gap-6 sm:gap-8">
          {filteredProjects.map((project, index) => (
            <Reveal 
              key={project.id} 
              direction={index % 2 === 0 ? "left" : "right"} 
              delay={150 + (index * 80)} 
              className="h-full"
            >
              <article 
                className="bg-slate-50 dark:bg-[#0B0F19] rounded-2xl overflow-hidden border border-slate-200 dark:border-white/[0.08] hover:border-blue-500/50 flex flex-col h-full group transition-all duration-300 hover:-translate-y-1 hover:shadow-xl shadow-sm"
                aria-labelledby={`project-title-${project.id}`}
              >
                
                {/* Media Image / Schematic Showcase (Accessible Button) */}
                <button
                  type="button"
                  onClick={() => onOpenProjectModal(project)}
                  aria-label={`View verified technical specifications and details for ${project.title}`}
                  className="w-full text-left relative block focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-inset cursor-pointer"
                >
                  <ProjectVisual project={project} />
                  
                  {/* Category Pill Tag Overlay */}
                  <div className="absolute top-3.5 left-3.5 z-20">
                    <span className="text-[10px] sm:text-[11px] font-mono font-semibold uppercase tracking-wider text-white bg-slate-900/80 backdrop-blur-md border border-white/20 px-2.5 py-1 rounded">
                      {project.category}
                    </span>
                  </div>

                  {/* Quick Click Hint Overlay on Hover / Focus */}
                  <div className="absolute top-3.5 right-3.5 z-20 opacity-0 group-hover:opacity-100 group-focus-within:opacity-100 transition-opacity">
                    <span className="text-xs font-mono bg-blue-600 text-white px-2.5 py-1 rounded shadow-md">
                      Inspect Details ↗
                    </span>
                  </div>
                </button>
                
                {/* Card Content */}
                <div className="p-5 sm:p-7 flex flex-col flex-grow">
                  <h3 id={`project-title-${project.id}`} className="mb-3">
                    <button
                      type="button"
                      onClick={() => onOpenProjectModal(project)}
                      className="text-left font-bold text-xl sm:text-2xl text-slate-900 dark:text-white hover:text-blue-600 dark:hover:text-blue-400 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 rounded-lg transition-colors cursor-pointer w-full"
                    >
                      {project.title}
                    </button>
                  </h3>
                  
                  <p className="text-slate-600 dark:text-slate-300 text-sm sm:text-base leading-relaxed mb-6 flex-grow">
                    {project.description}
                  </p>
                  
                  {/* Verified Tech Tags */}
                  <div className="flex flex-wrap gap-1.5 sm:gap-2 mb-6" aria-label="Technologies used">
                    {project.tags.map((tag, idx) => (
                      <span 
                        key={idx} 
                        className="text-xs font-mono text-slate-700 dark:text-slate-300 bg-white dark:bg-white/[0.04] border border-slate-200 dark:border-white/[0.06] px-2.5 py-1 rounded-md"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                  
                  {/* Interactive Action Bar with Distinct Semantic Controls */}
                  <div className="mt-auto pt-4 border-t border-slate-200 dark:border-white/[0.08] flex flex-wrap items-center justify-between gap-3">
                    {/* Primary Architecture Action */}
                    <button
                      type="button"
                      onClick={() => onOpenProjectModal(project)}
                      className="inline-flex items-center gap-1.5 text-xs font-mono font-semibold text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 hover:underline transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 rounded p-1 cursor-pointer"
                      aria-label={`View verified architecture and features for ${project.title}`}
                    >
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                      </svg>
                      <span>Verified Details</span>
                    </button>

                    {/* External Link Action Group */}
                    <div className="flex items-center gap-2">
                      {/* Live Demo Action */}
                      {project.liveLink ? (
                        <a 
                          href={project.liveLink} 
                          target="_blank" 
                          rel="noopener noreferrer" 
                          className="inline-flex items-center gap-1 text-xs font-semibold uppercase tracking-wider text-blue-600 dark:text-white hover:text-blue-700 dark:hover:text-blue-400 transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 rounded px-2 py-1"
                          aria-label={`Open ${project.title} live demo in a new tab`}
                        >
                          <span>Live App</span>
                          <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                          </svg>
                        </a>
                      ) : (
                        <span 
                          className="text-[11px] font-mono text-slate-500 dark:text-slate-400 bg-slate-200/70 dark:bg-slate-800/70 px-2 py-0.5 rounded border border-slate-300/60 dark:border-white/[0.06]"
                          title="Live deployment URL pending from project maintainer"
                        >
                          Live Link Pending
                        </span>
                      )}

                      {/* Specific Repository Action */}
                      {project.repoLink ? (
                        <a
                          href={project.repoLink}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1 text-xs font-semibold uppercase tracking-wider text-slate-700 dark:text-slate-300 hover:text-blue-600 dark:hover:text-white transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 rounded px-2 py-1"
                          aria-label={`View ${project.title} source code on GitHub in a new tab`}
                        >
                          <span>Code</span>
                          <svg className="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                            <path fillRule="evenodd" clipRule="evenodd" d="M12 2C6.477 2 2 6.477 2 12c0 4.42 2.865 8.166 6.839 9.489.5.092.682-.217.682-.482 0-.237-.008-.866-.013-1.699-2.782.604-3.369-1.34-3.369-1.34-.454-1.156-1.11-1.464-1.11-1.464-.908-.62.069-.608.069-.608 1.003.07 1.531 1.03 1.531 1.03.892 1.529 2.341 1.087 2.91.831.092-.646.35-1.086.636-1.336-2.22-.253-4.555-1.11-4.555-4.943 0-1.091.39-1.984 1.029-2.683-.103-.253-.446-1.27.098-2.647 0 0 .84-.269 2.75 1.025A9.564 9.564 0 0112 6.844c.85.004 1.705.115 2.504.337 1.909-1.294 2.747-1.025 2.747-1.025.546 1.377.203 2.394.1 2.647.64.699 1.028 1.592 1.028 2.683 0 3.842-2.339 4.687-4.566 4.935.359.309.678.919.678 1.852 0 1.336-.012 2.415-.012 2.743 0 .267.18.578.688.48C19.138 20.161 22 16.418 22 12c0-5.523-4.477-10-10-10z"/>
                          </svg>
                        </a>
                      ) : (
                        <span 
                          className="text-[11px] font-mono text-slate-500 dark:text-slate-400 bg-slate-200/70 dark:bg-slate-800/70 px-2 py-0.5 rounded border border-slate-300/60 dark:border-white/[0.06]"
                          title="Specific repository link pending from project maintainer"
                        >
                          Repo Pending
                        </span>
                      )}
                    </div>
                  </div>
                </div>

              </article>
            </Reveal>
          ))}
        </div>
        
      </div>
    </section>
  );
}