import React, { useState, useMemo } from 'react';
import Reveal from './Reveal';
import { skillsCategories } from '../data/skillsData';

export default function Skills() {
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');

  const categories = useMemo(() => {
    return ['All', ...skillsCategories.map(c => c.category)];
  }, []);

  const filteredSkills = useMemo(() => {
    const query = searchQuery.toLowerCase().trim();
    
    let result = [];
    skillsCategories.forEach(group => {
      if (selectedCategory === 'All' || group.category === selectedCategory) {
        group.skills.forEach(skill => {
          if (!query || skill.toLowerCase().includes(query)) {
            result.push({
              name: skill,
              category: group.category
            });
          }
        });
      }
    });

    return result;
  }, [selectedCategory, searchQuery]);

  return (
    <section id="skills" className="py-28 px-6 bg-slate-50 dark:bg-[#07090E] transition-colors duration-300 overflow-hidden border-t border-slate-200 dark:border-white/[0.04]">
      <div className="max-w-6xl mx-auto">
        
        {/* Section Header */}
        <Reveal direction="up" delay={0}>
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
            <div>
              <span className="text-xs font-mono font-semibold uppercase tracking-wider text-blue-600 dark:text-blue-400">
                02. Technical Arsenal
              </span>
              <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-slate-900 dark:text-white tracking-tight mt-2">
                Categorized Skills Explorer
              </h2>
              <div className="w-16 h-1 bg-blue-600 mt-4 rounded-full"></div>
            </div>

            {/* Instant Search Bar */}
            <div className="w-full md:w-72 relative">
              <input
                type="text"
                placeholder="Search tools & skills..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-white dark:bg-[#0C101B] border border-slate-300 dark:border-white/10 rounded-xl px-4 py-2.5 pl-10 text-sm text-slate-900 dark:text-slate-200 placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all shadow-sm"
              />
              <svg 
                className="w-4 h-4 text-slate-400 dark:text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2" 
                fill="none" 
                stroke="currentColor" 
                viewBox="0 0 24 24"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-700 dark:hover:text-white"
                  aria-label="Clear search"
                >
                  ✕
                </button>
              )}
            </div>
          </div>
        </Reveal>

        {/* Category Tabs (Segmented Button Controls) */}
        <Reveal direction="up" delay={100}>
          <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-8 scrollbar-none">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-4 py-2 text-xs sm:text-sm font-medium rounded-xl whitespace-nowrap transition-all duration-200 cursor-pointer ${
                  selectedCategory === cat
                    ? 'bg-blue-600 text-white shadow-md shadow-blue-500/20'
                    : 'bg-white dark:bg-[#0E1321] text-slate-700 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-[#151D33] border border-slate-200 dark:border-white/[0.06] shadow-sm'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </Reveal>

        {/* Active Results Metric */}
        <div className="flex items-center justify-between text-xs font-mono text-slate-500 dark:text-slate-400 mb-6">
          <span>
            Showing <span className="text-blue-600 dark:text-blue-400 font-semibold">{filteredSkills.length}</span> technologies
          </span>
          {searchQuery && (
            <span>Filtered by "{searchQuery}"</span>
          )}
        </div>

        {/* Skills Grid */}
        {filteredSkills.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3.5 sm:gap-4">
            {filteredSkills.map((item, index) => (
              <div 
                key={`${item.name}-${index}`}
                className="p-3.5 sm:p-4 rounded-xl bg-white dark:bg-[#0B0F1A] border border-slate-200 dark:border-white/[0.06] hover:border-blue-500/40 hover:bg-slate-50 dark:hover:bg-[#0E1424] transition-all duration-200 flex flex-col justify-between group hover:-translate-y-0.5 shadow-sm"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] font-mono text-slate-500 dark:text-slate-400 uppercase tracking-wider truncate">
                    {item.category}
                  </span>
                  <span className="w-1.5 h-1.5 rounded-full bg-blue-500 group-hover:scale-125 transition-transform"></span>
                </div>
                <span className="text-sm sm:text-base font-semibold text-slate-800 dark:text-slate-200 group-hover:text-blue-600 dark:group-hover:text-white transition-colors">
                  {item.name}
                </span>
              </div>
            ))}
          </div>
        ) : (
          <div className="p-12 text-center rounded-2xl bg-white dark:bg-[#0B0F1A] border border-slate-200 dark:border-white/[0.06] shadow-sm">
            <p className="text-slate-600 dark:text-slate-400 text-base mb-3">No technologies match your current search query.</p>
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedCategory('All');
              }}
              className="px-4 py-2 text-xs font-medium bg-blue-50 dark:bg-blue-600/20 text-blue-600 dark:text-blue-400 rounded-lg hover:bg-blue-100 dark:hover:bg-blue-600/30 transition-colors"
            >
              Reset Filters
            </button>
          </div>
        )}

      </div>
    </section>
  );
}
