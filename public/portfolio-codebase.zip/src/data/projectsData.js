/**
 * Authentic Project Showcase Data for Noor Setia
 * 
 * Strict Authenticity Guidelines:
 * - Only verified capabilities and tech stacks from actual project code are documented.
 * - Live URLs are only included when confirmed active.
 * - Generic profile URLs are removed from repoLink to avoid misrepresenting repositories.
 * - Unrelated stock photography is completely removed.
 * - screenshotUrl is prepared for Noor to supply genuine screenshots directly into /src/assets/projects/
 */

export const projectsData = [
  {
    id: 1,
    title: "NESTORA — MERN E-Commerce Platform",
    category: "MERN Stack",
    description: "A full-stack e-commerce platform for books, interiors, and furniture, built to provide a complete product discovery, shopping, and checkout experience. Features user and Google authentication, product browsing, shopping cart, order workflow, Razorpay payment integration, and state management with Zustand.",
    tags: ["React", "Node.js", "Express.js", "MongoDB", "Mongoose", "Zustand", "Razorpay", "REST APIs"],
    // Screenshot: supply path when ready (e.g. '/src/assets/projects/nestora.png')
    screenshotUrl: null,
    screenshotPlaceholder: "E-Commerce Catalog, Shopping Cart & Razorpay Checkout Workflow",
    // Verified URLs:
    liveLink: null, // Pending deployment URL from Noor Setia
    repoLink: null, // Pending specific repository URL from Noor Setia
    verifiedCapabilities: [
      "User credentials and Google OAuth authentication workflows",
      "Dynamic catalog browsing for books, interior items, and furniture",
      "Client-side shopping cart state management powered by Zustand",
      "Integrated checkout transaction pipeline with Razorpay payment gateway",
      "Modular Express.js backend REST API endpoints with middleware validation",
      "MongoDB database modeling using Mongoose schemas for orders, products, and users"
    ]
  },
  {
    id: 2,
    title: "CareSync — React Healthcare Portal",
    category: "Frontend & UI",
    description: "A responsive React-based healthcare portal designed to provide a structured and user-friendly digital experience for healthcare-related workflows. Features reusable components, client-side routing, interactive forms, and a structured frontend architecture with responsive layouts.",
    tags: ["React", "JavaScript", "HTML5", "CSS3", "React Router", "Bootstrap"],
    screenshotUrl: null,
    screenshotPlaceholder: "Healthcare Patient Dashboard, Clinical Forms & Scheduling Workflow",
    liveLink: null, // Pending deployment URL from Noor Setia
    repoLink: null, // Pending specific repository URL from Noor Setia
    verifiedCapabilities: [
      "Modular component hierarchy with reusable UI patterns and layouts",
      "Multi-view client-side routing powered by React Router",
      "Structured clinical appointment and patient inquiry forms with input validation",
      "Responsive cross-device layouts styled with Bootstrap and modern CSS"
    ]
  },
  {
    id: 3,
    title: "World Countries Data Explorer",
    category: "Data & Tools",
    description: "Built an interactive explorer allowing users to search, sort, and visualize country data dynamically. Features real-time filtering, multi-criteria sorting, and interactive charts displaying top populated countries and most spoken languages.",
    tags: ["JavaScript (ES6+)", "Chart.js", "HTML5 / CSS3", "DOM Manipulation"],
    screenshotUrl: null,
    screenshotPlaceholder: "Interactive Demographic Data Explorer, Search Filters & Chart.js Visuals",
    liveLink: "https://worldvisual.netlify.app/", // Verified working live deployment
    repoLink: null, // Pending specific repository URL from Noor Setia
    verifiedCapabilities: [
      "Instant real-time search across global country records with debounced input",
      "Multi-criteria column sorting across demographic indicators and country metrics",
      "Interactive data visualizations powered by Chart.js for population and languages",
      "Lightweight vanilla JavaScript (ES6+) architecture with native DOM manipulation"
    ]
  },
  {
    id: 4,
    title: "GYM – MERN Platform",
    category: "MERN Stack",
    description: "A responsive fitness platform with workout sections, pricing plans, and a BMI calculator. Integrated REST APIs using Node.js and Express for form handling and MongoDB for data operations.",
    tags: ["React", "MongoDB", "Node.js", "Express"],
    screenshotUrl: null,
    screenshotPlaceholder: "Fitness Regimen Split, Membership Tier Explorer & BMI Calculator",
    liveLink: "https://gym-frontend-eiqi.onrender.com/", // Verified working live deployment
    repoLink: null, // Pending specific repository URL from Noor Setia
    verifiedCapabilities: [
      "Interactive fitness training regimen displays and membership pricing tiers",
      "Real-time client-side Body Mass Index (BMI) calculator with health classifications",
      "REST API integration with Node.js and Express for contact and inquiry processing",
      "MongoDB database operations for membership signups and inquiry persistence"
    ]
  }
];
